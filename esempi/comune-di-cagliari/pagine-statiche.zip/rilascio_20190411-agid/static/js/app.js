var app = angular.module('ponmetroca', ['ngSanitize', 'ngMaterial']); 

var appricerca = angular.module('ponmetroca_ricerca', ['ngSanitize', 'ngMaterial']); 